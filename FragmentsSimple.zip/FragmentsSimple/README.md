# FragmentsSimple
Android: Fragments simple
